#!/usr/bin/env ruby
#
#    This program can be distributed under the terms of the GNU GPL.
#    See the file COPYING.
#
#    Author: Martin P�rtel <martin.partel@gmail.com>
#


require 'fileutils.rb'
include FileUtils

EXECUTABLE_PATH = '../src/bindfs'
TESTDIR_NAME = 'tmp_test_bindfs'

# Prepares a test environment with a mounted directory
def testenv(testcase_title, bindfs_args, &block)

    puts "--- #{testcase_title} ---"
    puts "[  #{bindfs_args}  ]"

    begin
        Dir.mkdir TESTDIR_NAME
    rescue Exception => ex
        $stderr.puts "ERROR creating testdir at #{TESTDIR_NAME}"
        exit! 1
    end

    begin
        Dir.chdir TESTDIR_NAME
        Dir.mkdir 'src'
        Dir.mkdir 'mnt'
    rescue Exception => ex
        $stderr.puts "ERROR preparing testdir at #{TESTDIR_NAME}"
        $stderr.puts ex
        exit! 1
    end

    bindfs_pid = nil
    begin
        cmd = "../#{EXECUTABLE_PATH} #{bindfs_args} src mnt"
        bindfs_pid = Process.fork do
            exec cmd
            exit! 127
        end
    rescue Exception => ex
        $stderr.puts "ERROR running bindfs"
        $stderr.puts ex
        Dir.chdir '..'
        system("rm -Rf #{TESTDIR_NAME}")
        exit! 1
    end

    # Wait for bindfs to daemonize itself
    Process.wait bindfs_pid

    # TODO: check that mounting was successful

    testcase_ok = true
    begin
        yield
    rescue Exception => ex
        $stderr.puts "ERROR: testcase `#{testcase_title}' failed"
        $stderr.puts ex
        $stderr.puts ex.backtrace
        testcase_ok = false
    end

    begin
        unless system('fusermount -uz mnt')
            raise Exception.new("fusermount -u failed with status #{$?}")
        end
    rescue Exception => ex
        $stderr.puts "ERROR: failed to umount"
        $stderr.puts ex
        $stderr.puts ex.backtrace
        testcase_ok = false
    end

    begin
        Dir.chdir '..'
    rescue Exception => ex
        $stderr.puts "ERROR: failed to exit test env"
        $stderr.puts ex
        $stderr.puts ex.backtrace
        exit! 1
    end

    unless system "rm -Rf #{TESTDIR_NAME}"
        $stderr.puts "ERROR: failed to clear test directory"
        exit! 1
    end

    if testcase_ok
        puts "OK"
    else
        exit! 1
    end
end


def assert
    raise Exception.new('test failed') unless yield
end

def assert_exception(ex)
    begin
        yield
    rescue ex
        return
    end
    raise Exception.new('expected exception ' + ex.to_s)
end


### MAIN ###

# Some useful shorthands
nobody_uid = Etc.getpwnam('nobody').uid
nogroup_gid = Etc.getgrnam('nogroup').gid


# Let's start by checking that mounting works at all
testenv('mounting', "") do
    assert { File.basename(pwd) == TESTDIR_NAME }
end

# Setting the owner of files to nobody/nogroup
testenv('set_owner', "-u nobody -g nogroup") do
    touch('src/file')

    assert { File.stat('mnt/file').uid == nobody_uid }
    assert { File.stat('mnt/file').gid == nogroup_gid }
end

# Setting permission bits
testenv('permbits', "-p 0600:u+D") do
    touch('src/file')
    chmod(0777, 'src/file')

    assert { File.stat('mnt/file').mode & 0777 == 0600 }
end

# Setting the file owner
testenv('simple_pattern', "-u nobody") do
    touch('src/file')

    assert { File.stat('mnt/file').uid == nobody_uid }
end

# Test setting chmod policy
testenv('chmod_policy', "--chmod-deny") do
    touch('src/file')

    assert_exception(Errno::EPERM) { chmod(0777, 'mnt/file') }
end

# Test --mirror
testenv('mirror', "-u nobody -m #{Process.uid} -p 0600,u+D") do
    touch('src/file')

    assert { File.stat('mnt/file').uid == Process.uid }
end

# Test --create-with-perms
testenv('create_with_perms', "--create-with-perms=og=r:ogd+x") do
    touch('src/file')
    mkdir('src/dir')

    assert { File.stat('mnt/file').mode & 0077 == 0044 }
    assert { File.stat('mnt/dir').mode & 0077 == 0055 }
end
