/*
    This program can be distributed under the terms of the GNU GPL.
    See the file COPYING.

    Author: Martin P�rtel <martin.partel@gmail.com>
*/

#ifndef INC_BINDFS_DEBUG_H
#define INC_BINDFS_DEBUG_H

#include <config.h>

#if BINDFS_DEBUG
#include <stdio.h>
#define DPRINTF(...) fprintf(stderr, "DEBUG: " __VA_ARGS__)
#else
#define DPRINTF(...)
#endif

#endif

