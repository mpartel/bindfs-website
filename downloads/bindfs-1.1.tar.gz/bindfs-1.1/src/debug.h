
#ifndef INC_BINDFS_DEBUG_H
#define INC_BINDFS_DEBUG_H

#include <config.h>

#if BINDFS_DEBUG
#include <stdio.h>
#define DPRINTF(...) fprintf(stderr, "DEBUG: " __VA_ARGS__)
#else
#define DPRINTF(...)
#endif

#endif

