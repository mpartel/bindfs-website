
#ifndef INC_BINDFS_MISC_H
#define INC_BINDFS_MISC_H

/* Counts the number of times ch occurs in the string. */
int count_chars(const char *s, char ch);

/* Creates a duplicate string of all the characters in s before
   an end character is reached. */
char *strdup_until(const char *s, const char *endchars);

#endif
