/*
    This program can be distributed under the terms of the GNU GPL.
    See the file COPYING.

    Author: Martin P�rtel <martin.partel@gmail.com>


    Based on the fusexmp_fh.c in FUSE 2.5.3 with the following notice:
    ---
    FUSE: Filesystem in Userspace
    Copyright (C) 2001-2006  Miklos Szeredi <miklos@szeredi.hu>

    This program can be distributed under the terms of the GNU GPL.
    See the file COPYING.
    ---

*/

#include <config.h>

#define _GNU_SOURCE

#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#ifdef HAVE_SYS_TYPES_H
#include <sys/types.h>
#endif
#ifdef HAVE_SYS_STAT_H
#include <sys/stat.h>
#endif
#include <sys/statvfs.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <assert.h>
#include <pwd.h>
#include <grp.h>
#ifdef HAVE_SETXATTR
#include <sys/xattr.h>
#endif

#include <fuse.h>
#include <fuse_opt.h>

#include "debug.h"
#include "permchain.h"
#include "userinfo.h"
#include "misc.h"

/* SETTINGS */
static struct settings {
    const char *progname;
    struct permchain *permchain; /* permission bit rules. see permchain.h */
    uid_t new_uid; /* user-specified uid */
    gid_t new_gid; /* user-specified gid */
    const char *mntsrc;
    const char *mntdest;
    int mntsrc_fd;

    enum CreatePolicy {
        CREATE_AS_USER,
        CREATE_AS_MOUNTER
    } create_policy;

    enum ChmodPolicy {
        CHMOD_NORMAL,
        CHMOD_IGNORE,
        CHMOD_DENY
    } chmod_policy;

    enum XAttrPolicy {
        XATTR_UNIMPLEMENTED,
        XATTR_READ_ONLY,
        XATTR_READ_WRITE
    } xattr_policy;

    int mirrored_users_only;
    uid_t* mirrored_users;
    int num_mirrored_users;

} settings;



/* PROTOTYPES */

/* Check permissions to do open.
   mask must be a combination of R_OK, W_OK, X_OK, F_OK.
   0 on success, -errno on failure. */
static int check_stat_access(struct stat st, int mask, uid_t uid, gid_t main_gid);

/* Does the statting and calls check_stat_access. path must be processed.
   0 on success, -errno on failure. */
static int check_access(const char *procpath, int mask);

/* Processes the virtual path to a real path. Don't free() the result. */
static const char *process_path(const char *path);

/* A thread-safe dirname.
   Simply returns everything before the final '/', or a '.'.
   (should work for the well-behaved pathnames fuse provides (FIXME?))
   Result should be free()'ed! */
static char *my_dirname(const char *path);

/* The common parts of getattr and fgetattr */
static int getattr_common(const char *path, struct stat *stbuf);


/* FUSE callbacks */
static void *bindfs_init();
static void bindfs_destroy(void *private_data);
static int bindfs_getattr(const char *path, struct stat *stbuf);
static int bindfs_fgetattr(const char *path, struct stat *stbuf,
                           struct fuse_file_info *fi);
static int bindfs_access(const char *path, int mask);
static int bindfs_readlink(const char *path, char *buf, size_t size);
static int bindfs_opendir(const char *path, struct fuse_file_info *fi);
static inline DIR *get_dirp(struct fuse_file_info *fi);
static int bindfs_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
                          off_t offset, struct fuse_file_info *fi);
static int bindfs_releasedir(const char *path, struct fuse_file_info *fi);
static int bindfs_mknod(const char *path, mode_t mode, dev_t rdev);
static int bindfs_mkdir(const char *path, mode_t mode);
static int bindfs_unlink(const char *path);
static int bindfs_rmdir(const char *path);
static int bindfs_symlink(const char *from, const char *to);
static int bindfs_rename(const char *from, const char *to);
static int bindfs_link(const char *from, const char *to);
static int bindfs_chmod(const char *path, mode_t mode);
static int bindfs_chown(const char *path, uid_t uid, gid_t gid);
static int bindfs_truncate(const char *path, off_t size);
static int bindfs_ftruncate(const char *path, off_t size,
                            struct fuse_file_info *fi);
static int bindfs_utime(const char *path, struct utimbuf *buf);
static int bindfs_create(const char *path, mode_t mode, struct fuse_file_info *fi);
static int bindfs_open(const char *path, struct fuse_file_info *fi);
static int bindfs_read(const char *path, char *buf, size_t size, off_t offset,
                       struct fuse_file_info *fi);
static int bindfs_write(const char *path, const char *buf, size_t size,
                        off_t offset, struct fuse_file_info *fi);
static int bindfs_statfs(const char *path, struct statvfs *stbuf);
static int bindfs_release(const char *path, struct fuse_file_info *fi);
static int bindfs_fsync(const char *path, int isdatasync,
                        struct fuse_file_info *fi);


static void print_usage(const char *progname);
static void atexit_func();
static int process_option(void *data, const char *arg, int key,
                          struct fuse_args *outargs);


static int check_stat_access(struct stat st, int mask, uid_t uid, gid_t main_gid)
{
    /* Report user-defined owner/group if specified */
    uid_t own = (settings.new_uid == -1) ? st.st_uid : settings.new_uid;
    gid_t grp = (settings.new_gid == -1) ? st.st_gid : settings.new_gid;
    int needed;
    int i;

    /* Does the calling process have root privileges? */
    if (uid == 0)
        return 0;

    /* Mirror for this user? */
    for (i = 0; i < settings.num_mirrored_users; ++i)
        if (settings.mirrored_users[i] == uid)
            break;
    if (i < settings.num_mirrored_users)
        own = uid;
    else if (settings.mirrored_users_only)
        return -EACCES;

    /* FIXME: what to do about F_OK? */
    needed = 0000;
    if (mask & R_OK)
        needed |= 0444;
    if (mask & W_OK)
        needed |= 0222;
    if (mask & X_OK)
        needed |= 0111;

    if (needed == 0000) /* invalid arguments */
        return -EINVAL;

    if (own == uid) {
        if ((st.st_mode & 0700 & needed) == (0700 & needed))
            return 0;
    }
    if (grp == main_gid || user_belongs_to_group(uid, grp)) {

        if ((st.st_mode & 0070 & needed) == (0070 & needed))
            return 0;
    }
    if ((st.st_mode & 0007 & needed) == (0007 & needed))
        return 0;

    return -EACCES;
}

static int check_access(const char *procpath, int mask)
{
    int ret;
    struct stat st;
    struct fuse_context *fc = fuse_get_context();

    if (access(procpath, mask) == -1)
        return -errno;

    if (lstat(procpath, &st) == -1)
        return -errno;

    st = permchain_apply(settings.permchain, st);
    ret = check_stat_access(st, mask, fc->uid, fc->gid);
    if (ret == 0)
        return 0;
    else
        return ret;
}


static const char *process_path(const char *path)
{
    if (path == NULL) /* possible? */
        return NULL;

    while (*path == '/')
        ++path;

    if (*path == '\0')
        return ".";
    else
        return path;
}

static char *my_dirname(const char *path)
{
    char *ret = NULL;
    const char *lastslash = strrchr(path, '/');
    int len = lastslash - path;

    if (lastslash) {
        ret = malloc((len + 1) * sizeof(char));
        memcpy(ret, path, len);
        ret[len] = '\0';
    } else {
        ret = strdup(".");
    }

    return ret;
}

static int getattr_common(const char *procpath, struct stat *stbuf)
{
    struct fuse_context *fc = fuse_get_context();
    int i;

    /* Report user-defined owner/group if specified */
    if (settings.new_uid != -1)
        stbuf->st_uid = settings.new_uid;
    if (settings.new_gid != -1)
        stbuf->st_gid = settings.new_gid;

    /* Mirrored user? */
    for (i = 0; i < settings.num_mirrored_users; ++i)
        if (settings.mirrored_users[i] == fc->uid)
            break;
    if (i < settings.num_mirrored_users)
        stbuf->st_uid = fc->uid;

    if ((stbuf->st_mode & S_IFLNK) == S_IFLNK)
        return 0; /* don't modify link permission bits */

    /* Apply user-defined permission bit modifications */
    *stbuf = permchain_apply(settings.permchain, *stbuf);

    /* Check that we can really do what we promise */
    if (access(procpath, R_OK) == -1)
        stbuf->st_mode &= ~0444;
    if (access(procpath, W_OK) == -1)
        stbuf->st_mode &= ~0222;
    if (access(procpath, X_OK) == -1)
        stbuf->st_mode &= ~0111;

    return 0;
}

static void *bindfs_init()
{
    assert(settings.permchain != NULL);
    assert(settings.mntsrc_fd > 0);

    if (fchdir(settings.mntsrc_fd) != 0) {
        fprintf(
            stderr,
            "Could not change working directory to '%s': %s\n",
            settings.mntsrc,
            strerror(errno)
            );
        fuse_exit(fuse_get_context()->fuse);
    }

    return NULL;
}

static void bindfs_destroy(void *private_data)
{
}

static int bindfs_getattr(const char *path, struct stat *stbuf)
{
    path = process_path(path);

    if (lstat(path, stbuf) == -1)
        return -errno;
    return getattr_common(path, stbuf);
}

static int bindfs_fgetattr(const char *path, struct stat *stbuf,
                           struct fuse_file_info *fi)
{
    path = process_path(path);

    if (fstat(fi->fh, stbuf) == -1)
        return -errno;
    return getattr_common(path, stbuf);
}

static int bindfs_access(const char *path, int mask)
{
    path = process_path(path);

    return check_access(path, mask);
}

static int bindfs_readlink(const char *path, char *buf, size_t size)
{
    int res;

    path = process_path(path);

    res = check_access(path, R_OK);
    if (res < 0)
        return res;

    res = readlink(path, buf, size - 1);
    if (res == -1)
        return -errno;

    buf[res] = '\0';
    return 0;
}

static int bindfs_opendir(const char *path, struct fuse_file_info *fi)
{
    DIR *dp;
    int res;

    path = process_path(path);

    res = check_access(path, R_OK);
    if (res < 0)
        return res;

    dp = opendir(path);
    if (dp == NULL)
        return -errno;

    fi->fh = (unsigned long) dp;
    return 0;
}

static inline DIR *get_dirp(struct fuse_file_info *fi)
{
    return (DIR *) (uintptr_t) fi->fh;
}

static int bindfs_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
                          off_t offset, struct fuse_file_info *fi)
{
    DIR *dp = get_dirp(fi);
    struct dirent *de;

    (void) path;
    seekdir(dp, offset);
    while ((de = readdir(dp)) != NULL) {
        struct stat st;
        memset(&st, 0, sizeof(st));
        st.st_ino = de->d_ino;
        st.st_mode = de->d_type << 12;
        if (filler(buf, de->d_name, &st, telldir(dp)))
            break;
    }

    return 0;
}

static int bindfs_releasedir(const char *path, struct fuse_file_info *fi)
{
    DIR *dp = get_dirp(fi);
    (void) path;
    closedir(dp);
    return 0;
}

static int bindfs_mknod(const char *path, mode_t mode, dev_t rdev)
{
    int res;
    char *dir;

    path = process_path(path);
    dir = my_dirname(path);

    res = check_access(dir, W_OK);
    if (res < 0) {
        free(dir);
        return res;
    }

    if (S_ISFIFO(mode))
        res = mkfifo(path, mode);
    else
        res = mknod(path, mode, rdev);
    if (res == -1) {
        free(dir);
        return -errno;
    }

    free(dir);
    return 0;
}

static int bindfs_mkdir(const char *path, mode_t mode)
{
    int res;
    char *dir;
    struct fuse_context *fc;

    path = process_path(path);
    dir = my_dirname(path);

    res = check_access(dir, W_OK);
    if (res < 0) {
        free(dir);
        return res;
    }

    res = mkdir(path, mode);
    if (res == -1) {
        free(dir);
        return -errno;
    }

    if (settings.create_policy == CREATE_AS_USER) {
        fc = fuse_get_context();
        chown(path, fc->uid, fc->gid);
    }

    free(dir);
    return 0;
}

static int bindfs_unlink(const char *path)
{
    int res;

    path = process_path(path);

    res = check_access(path, W_OK);
    if (res < 0)
        return res;

    res = unlink(path);
    if (res == -1)
        return -errno;

    return 0;
}

static int bindfs_rmdir(const char *path)
{
    int res;

    path = process_path(path);

    res = check_access(path, W_OK);
    if (res < 0)
        return res;

    res = rmdir(path);
    if (res == -1)
        return -errno;

    return 0;
}

static int bindfs_symlink(const char *from, const char *to)
{
    int res;
    char *dir;

    from = process_path(from);
    to = process_path(to);
    dir = my_dirname(to);

    res = check_access(dir, W_OK);
    if (res < 0) {
        free(dir);
        return res;
    }

    res = symlink(from, to);
    if (res == -1) {
        free(dir);
        return -errno;
    }

    free(dir);
    return 0;
}

static int bindfs_rename(const char *from, const char *to)
{
    int res;
    char *dir;

    from = process_path(from);
    to = process_path(to);
    dir = my_dirname(to);

    res = check_access(dir, W_OK);
    if (res < 0) {
        free(dir);
        return res;
    }

    res = rename(from, to);
    if (res == -1) {
        free(dir);
        return -errno;
    }

    free(dir);
    return 0;
}

static int bindfs_link(const char *from, const char *to)
{
    int res;
    char *dir;

    from = process_path(from);
    to = process_path(to);
    dir = my_dirname(to);

    res = check_access(dir, W_OK);
    if (res < 0) {
        free(dir);
        return res;
    }

    res = link(from, to);
    if (res == -1) {
        free(dir);
        return -errno;
    }

    free(dir);
    return 0;
}

static int bindfs_chmod(const char *path, mode_t mode)
{
    int res;

    switch (settings.chmod_policy) {
    case CHMOD_NORMAL:
        path = process_path(path);

        res = chmod(path, mode);
        if (res == -1)
            return -errno;

        return 0;
    case CHMOD_IGNORE:
        return 0;
    case CHMOD_DENY:
        return -EPERM;
    default:
        assert(0);
    }
}

static int bindfs_chown(const char *path, uid_t uid, gid_t gid)
{
    int res;

    if ((uid != -1 && settings.new_uid != -1) ||
        (gid != -1 && settings.new_gid != -1))
        return -EPERM;

    path = process_path(path);

    res = lchown(path, uid, gid);
    if (res == -1)
        return -errno;

    return 0;
}

static int bindfs_truncate(const char *path, off_t size)
{
    int res;

    path = process_path(path);

    res = check_access(path, W_OK);
    if (res < 0)
        return res;

    res = truncate(path, size);
    if (res == -1)
        return -errno;

    return 0;
}

static int bindfs_ftruncate(const char *path, off_t size,
                            struct fuse_file_info *fi)
{
    int res;

    (void) path;

    res = ftruncate(fi->fh, size);
    if (res == -1)
        return -errno;

    return 0;
}

static int bindfs_utime(const char *path, struct utimbuf *buf)
{
    int res;

    path = process_path(path);

    res = check_access(path, R_OK);
    if (res < 0)
        return res;

    res = utime(path, buf);
    if (res == -1)
        return -errno;

    return 0;
}

static int bindfs_create(const char *path, mode_t mode, struct fuse_file_info *fi)
{
    int res;
    int fd;
    char *dir;
    struct fuse_context *fc;

    path = process_path(path);
    dir = my_dirname(path);

    res = check_access(dir, W_OK);
    if (res < 0) {
        free(dir);
        return res;
    }

    fd = open(path, fi->flags, mode);
    if (fd == -1) {
        free(dir);
        return -errno;
    }

    if (settings.create_policy == CREATE_AS_USER) {
        fc = fuse_get_context();
        chown(path, fc->uid, fc->gid);
    }

    fi->fh = fd;
    free(dir);
    return 0;
}

static int bindfs_open(const char *path, struct fuse_file_info *fi)
{
    int res = -1;
    int fd;

    path = process_path(path);

    if ((fi->flags & O_RDWR) == O_RDWR) {
        res = check_access(path, R_OK | W_OK);
    } else if ((fi->flags & O_RDONLY) == O_RDONLY) {
        res = check_access(path, R_OK);
    } else if ((fi->flags & O_WRONLY) == O_WRONLY) {
        res = check_access(path, W_OK);
    }

    if (res < 0)
        return res;

    fd = open(path, fi->flags);
    if (fd == -1)
        return -errno;

    fi->fh = fd;
    return 0;
}

static int bindfs_read(const char *path, char *buf, size_t size, off_t offset,
                       struct fuse_file_info *fi)
{
    int res;

    (void) path;
    res = pread(fi->fh, buf, size, offset);
    if (res == -1)
        res = -errno;

    return res;
}

static int bindfs_write(const char *path, const char *buf, size_t size,
                        off_t offset, struct fuse_file_info *fi)
{
    int res;

    (void) path;
    res = pwrite(fi->fh, buf, size, offset);
    if (res == -1)
        res = -errno;

    return res;
}

static int bindfs_statfs(const char *path, struct statvfs *stbuf)
{
    int res;

    path = process_path(path);

    res = statvfs(path, stbuf);
    if (res == -1)
        return -errno;

    return 0;
}

static int bindfs_release(const char *path, struct fuse_file_info *fi)
{
    (void) path;
    close(fi->fh);

    return 0;
}

static int bindfs_fsync(const char *path, int isdatasync,
                        struct fuse_file_info *fi)
{
    int res;
    (void) path;

#ifndef HAVE_FDATASYNC
    (void) isdatasync;
#else
    if (isdatasync)
        res = fdatasync(fi->fh);
    else
#endif
        res = fsync(fi->fh);
    if (res == -1)
        return -errno;

    return 0;
}

#ifdef HAVE_SETXATTR
static int bindfs_setxattr(const char *path, const char *name, const char *value,
                           size_t size, int flags)
{
    if (settings.xattr_policy == XATTR_READ_ONLY)
        return -EACCES;

    /* fuse checks permissions for us */
    path = process_path(path);
    if (lsetxattr(path, name, value, size, flags) == -1)
        return -errno;
    return 0;
}

static int bindfs_getxattr(const char *path, const char *name, char *value,
                           size_t size)
{
    int res;

    path = process_path(path);
    /* fuse checks permissions for us */
    res = lgetxattr(path, name, value, size);
    if (res == -1)
        return -errno;
    return res;
}

static int bindfs_listxattr(const char *path, char *list, size_t size)
{
    int res;

    path = process_path(path);
    /* fuse checks permissions for us */
    res = llistxattr(path, list, size);
    if (res == -1)
        return -errno;
    return res;
}

static int bindfs_removexattr(const char *path, const char *name)
{
    if (settings.xattr_policy == XATTR_READ_ONLY)
        return -EACCES;

    path = process_path(path);
    /* fuse checks permissions for us */
    if (lremovexattr(path, name) == -1)
        return -errno;
    return 0;
}
#endif /* HAVE_SETXATTR */


static struct fuse_operations bindfs_oper = {
    .init       = bindfs_init,
    .destroy    = bindfs_destroy,
    .getattr    = bindfs_getattr,
    .fgetattr   = bindfs_fgetattr,
    .access     = bindfs_access,
    .readlink   = bindfs_readlink,
    .opendir    = bindfs_opendir,
    .readdir    = bindfs_readdir,
    .releasedir = bindfs_releasedir,
    .mknod      = bindfs_mknod,
    .mkdir      = bindfs_mkdir,
    .symlink    = bindfs_symlink,
    .unlink     = bindfs_unlink,
    .rmdir      = bindfs_rmdir,
    .rename     = bindfs_rename,
    .link       = bindfs_link,
    .chmod      = bindfs_chmod,
    .chown      = bindfs_chown,
    .truncate   = bindfs_truncate,
    .ftruncate  = bindfs_ftruncate,
    .utime      = bindfs_utime,
    .create     = bindfs_create,
    .open       = bindfs_open,
    .read       = bindfs_read,
    .write      = bindfs_write,
    .statfs     = bindfs_statfs,
    .release    = bindfs_release,
    .fsync      = bindfs_fsync,
#ifdef HAVE_SETXATTR
    .setxattr   = bindfs_setxattr,
    .getxattr   = bindfs_getxattr,
    .listxattr  = bindfs_listxattr,
    .removexattr= bindfs_removexattr,
#endif
};

static void print_usage(const char *progname)
{
    if (progname == NULL)
        progname = "bindfs";

    printf("Usage: %s [options] dir mountpoint\n"
           "Information:\n"
           "  -h      --help            Print this and exit.\n"
           "  -V      --version         Print version number and exit.\n"
           "\n"
           "Options:\n"
           "  -u      --user, --owner   Set file owner.\n"
           "  -g      --group           Set file group.\n"
           "  -m      --mirror          Comma-separated list of users who will see\n"
           "                            themselves as the owners of all files.\n"
           "  -M      --mirror-only     Like --mirror but disallow access for\n"
           "                            all other users.\n"
           "  -n      --no-allow-others Do not add -o allow_others to fuse options.\n"
           "\n"
           "File creation policy:\n"
           "  --create-as-user          New files owned by creator (default for root).\n"
           "  --create-as-mounter       New files owned by fs mounter (default for users).\n"
           "\n"
           "Chmod policy:\n"
           "  --chmod-normal            Try to chmod the original files (the default).\n"
           "  --chmod-ignore            Have all chmods to fail silently.\n"
           "  --chmod-deny              Have all chmods fail with 'permission denied'.\n"
           "\n"
           "Extended attribute policy:\n"
           "  --xattr-none              Do not implement xattr operations.\n"
           "  --xattr-ro                Read-only xattr operations (the default).\n"
           "  --xattr-rw                Read-write xattr operations.\n"
           "\n"
           "Permission bits:\n"
           "  -p      --perms           Specify permissions similar to chmod\n"
           "                            e.g. og-x,og+rD,u=rwX,g+rw  or  0644,a+X\n"
           "\n"
           "FUSE options:\n"
           "  -o opt[,opt,...]          Mount options.\n"
           "  -d      -o debug          Enable debug output (implies -f).\n"
           "  -f                        Foreground operation.\n"
           "  -s                        Disable multithreaded operation.\n"
           "\n",
           progname);
}


static void atexit_func()
{
    permchain_destroy(settings.permchain);
}

enum OptionKey {
    OPTKEY_NONOPTION = -2,
    OPTKEY_UNKNOWN = -1,
    OPTKEY_HELP,
    OPTKEY_VERSION,
    OPTKEY_CREATE_AS_USER,
    OPTKEY_CREATE_AS_MOUNTER,
    OPTKEY_CHMOD_NORMAL,
    OPTKEY_CHMOD_IGNORE,
    OPTKEY_CHMOD_DENY,
    OPTKEY_XATTR_NONE,
    OPTKEY_XATTR_READ_ONLY,
    OPTKEY_XATTR_READ_WRITE
};

static int process_option(void *data, const char *arg, int key,
                          struct fuse_args *outargs)
{
    switch ((enum OptionKey)key)
    {
    case OPTKEY_HELP:
        printf("\n");
        print_usage(basename(settings.progname));
        exit(0);

    case OPTKEY_VERSION:
        printf("%s\n", PACKAGE_STRING);
        exit(0);

    case OPTKEY_CREATE_AS_USER:
        if (getuid() == 0)
            settings.create_policy = CREATE_AS_USER;
        else
            fprintf(stderr, "Warning: You need to be root to use --create-as-user !\n");
        return 0;
    case OPTKEY_CREATE_AS_MOUNTER:
        settings.create_policy = CREATE_AS_MOUNTER;
        return 0;

    case OPTKEY_CHMOD_NORMAL:
        settings.chmod_policy = CHMOD_NORMAL;
        return 0;
    case OPTKEY_CHMOD_IGNORE:
        settings.chmod_policy = CHMOD_IGNORE;
        return 0;
    case OPTKEY_CHMOD_DENY:
        settings.chmod_policy = CHMOD_DENY;
        return 0;

    case OPTKEY_XATTR_NONE:
        settings.xattr_policy = XATTR_UNIMPLEMENTED;
        return 0;
    case OPTKEY_XATTR_READ_ONLY:
        settings.xattr_policy = XATTR_READ_ONLY;
        return 0;
    case OPTKEY_XATTR_READ_WRITE:
        settings.xattr_policy = XATTR_READ_WRITE;
        return 0;

    case OPTKEY_NONOPTION:
        if (!settings.mntsrc) {
            settings.mntsrc = arg;
            return 0;
        } else if (!settings.mntdest) {
            settings.mntdest = arg;
            return 1; /* leave this argument for fuse_main */
        } else {
            fprintf(stderr, "Too many arguments given\n");
            return -1;
        }

    default:
        return 1;
    }
}


int main(int argc, char *argv[])
{
    struct fuse_args args = FUSE_ARGS_INIT(argc, argv);

    /* Fuse's option parser will store things here. */
    static struct OptionData {
        char *user;
        char *group;
        char *perms;
        char *mirror;
        char *mirror_only;
        int no_allow_others;
    } od = {NULL, NULL, NULL, NULL, NULL, 0};

    #define OPT2(one, two, key) \
            {one, -1, key}, \
            {two, -1, key}
    #define OPT3(one, two, three, key) \
            {one, -1, key}, \
            {two, -1, key}, \
            {three, -1, key}
    #define OPT_OFFSET2(one, two, offset, key) \
            {one, offsetof(struct OptionData, offset), key}, \
            {two, offsetof(struct OptionData, offset), key}
    #define OPT_OFFSET3(one, two, three, offset, key) \
            {one, offsetof(struct OptionData, offset), key}, \
            {two, offsetof(struct OptionData, offset), key}, \
            {three, offsetof(struct OptionData, offset), key}
    static const struct fuse_opt options[] = {
        OPT2("-h", "--help", OPTKEY_HELP),
        OPT2("-V", "--version", OPTKEY_VERSION),
        OPT_OFFSET2("-u %s", "--user=%s",              user, -1),
        OPT_OFFSET2(         "--owner=%s", "owner=%s", user, -1),
        OPT_OFFSET3("-g %s", "--group=%s", "group=%s", group, -1),
        OPT_OFFSET3("-p %s", "--perms=%s", "perms=%s", perms, -1),
        OPT_OFFSET3("-m %s", "--mirror=%s", "mirror=%s", mirror, -1),
        OPT_OFFSET3("-M %s", "--mirror-only=%s", "mirror-only=%s", mirror_only, -1),
        OPT_OFFSET3("-n", "--no-allow-others", "no-allow-others", no_allow_others, -1),
        OPT2("--create-as-user", "create-as-user", OPTKEY_CREATE_AS_USER),
        OPT2("--create-as-mounter", "create-as-mounter", OPTKEY_CREATE_AS_MOUNTER),
        OPT2("--chmod-normal", "chmod-normal", OPTKEY_CHMOD_NORMAL),
        OPT2("--chmod-ignore", "chmod-ignore", OPTKEY_CHMOD_IGNORE),
        OPT2("--chmod-deny", "chmod-deny", OPTKEY_CHMOD_DENY),
        OPT2("--xattr-none", "xattr-none", OPTKEY_XATTR_NONE),
        OPT2("--xattr-ro", "xattr-ro", OPTKEY_XATTR_READ_ONLY),
        OPT2("--xattr-rw", "xattr-rw", OPTKEY_XATTR_READ_WRITE),
        FUSE_OPT_END
    };

    /* General-purpose variables */
    int i;
    char *p, *tmpstr;

    int fuse_main_return;


    /* Initialize settings */
    settings.progname = argv[0];
    settings.permchain = permchain_create();
    settings.new_uid = -1;
    settings.new_gid = -1;
    settings.mntsrc = NULL;
    settings.mntdest = NULL;
    settings.create_policy = (getuid() == 0) ? CREATE_AS_USER : CREATE_AS_MOUNTER;
    settings.chmod_policy = CHMOD_NORMAL;
    settings.xattr_policy = XATTR_READ_ONLY;
    settings.mirrored_users_only = 0;
    settings.mirrored_users = NULL;
    settings.num_mirrored_users = 0;

    atexit(&atexit_func);

    /* Parse options */
    if (fuse_opt_parse(&args, &od, options, &process_option) == -1)
        return 1;

    /* Check that a source directory and a mount point was given */
    if (!settings.mntsrc || !settings.mntdest) {
        print_usage(basename(argv[0]));
        return 1;
    }

    /* Parse new owner and group */
    if (od.user) {
        if (!user_uid(od.user, &settings.new_uid)) {
            fprintf(stderr, "Not a valid user ID: %s\n", od.user);
            return 1;
        }
    }
    if (od.group) {
        if (!group_gid(od.group, &settings.new_gid)) {
            fprintf(stderr, "Not a valid group ID: %s\n", od.group);
            return 1;
        }
    }

    if (od.mirror && od.mirror_only) {
        fprintf(stderr, "Cannot specify both -m|--mirror and -M|--mirror-only\n");
        return 1;
    }
    if (od.mirror_only) {
        settings.mirrored_users_only = 1;
        od.mirror = od.mirror_only;
    }
    if (od.mirror) {
        settings.num_mirrored_users = count_chars(od.mirror, ',') + 1;
        settings.mirrored_users = realloc(settings.mirrored_users,
            settings.num_mirrored_users*sizeof(uid_t));

        i = 0;
        p = od.mirror;
        while (i < settings.num_mirrored_users) {
            tmpstr = strdup_until(p, ",:");
            if (!user_uid(tmpstr, &settings.mirrored_users[i])) {
                fprintf(stderr, "Invalid user ID: '%s'\n", tmpstr);
                free(tmpstr);
                return 1;
            }
            free(tmpstr);
            while (*p != ',')
                ++p;
            ++p;
            ++i;
        }
    }

    /* Parse permission bits */
    if (od.perms) {
        if (add_chmod_rules_to_permchain(od.perms, settings.permchain) != 0) {
            fprintf(stderr, "Invalid permission specification: '%s'\n", od.perms);
            return 1;
        }
    }


    /* Add default fuse options */
    if (!od.no_allow_others) {
        fuse_opt_add_arg(&args, "-oallow_other");
    }

    /* Weird things can happen if this is not set. */
    fuse_opt_add_arg(&args, "-odefault_permissions");

    /* Open mount source for chrooting in bindfs_init */
    settings.mntsrc_fd = open(settings.mntsrc, O_RDONLY);
    if (settings.mntsrc_fd == -1) {
        fprintf(stderr, "Could not open source directory\n");
        return 1;
    }

    /* Ignore the umask of the mounter on file creation */
    umask(0);

    /* Remove xattr implementation if the user doesn't want it */
    if (settings.xattr_policy == XATTR_UNIMPLEMENTED) {
        bindfs_oper.setxattr = NULL;
        bindfs_oper.getxattr = NULL;
        bindfs_oper.listxattr = NULL;
        bindfs_oper.removexattr = NULL;
    }

    fuse_main_return = fuse_main(args.argc, args.argv, &bindfs_oper);

    fuse_opt_free_args(&args);
    close(settings.mntsrc_fd);

    return fuse_main_return;
}
